jQuery(document).ready(function( $ ) {
	
	
	(function($) {
	
	// $ Works! You can test it with next line if you like
		console.log("hello word");
	
	})( jQuery );
});


