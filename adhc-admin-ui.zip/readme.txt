=== ADHC Admin UI ===
Contributors: Tyler Grace
Requires at least: 3.9.0
Tested up to: 4.7.1
Stable tag: 2.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Installation ==

1. Upload `fancy-admin-ui` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Set your custom colors via Settings > General
